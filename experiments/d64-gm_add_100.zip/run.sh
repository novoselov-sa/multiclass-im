reset && make && sage trees_generation.sage -3 -7 -11 -19 -23 -31 --gm-add 100 > experiments/trees_generation_d64-gm_add_100.log && sage testrelations.sage > experiments/testrelations_d64-gm_add_100.log

