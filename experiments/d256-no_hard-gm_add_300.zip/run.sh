reset && make && sage trees_generation.sage -3 -7 -11 -19 -23 -31 -43 -47 --gm-add 300 --no-hard-primes > experiments/trees_generation_d256-no_hard-gm_add_300.log && sage testrelations.sage > experiments/testrelations_d256-no_hard-gm_add_300.log

